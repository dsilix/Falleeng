//
//  MusicClass.swift
//  Gameplay
//
//  Created by Alessandro Volpe on 29/10/2020.
//

import Foundation
import SpriteKit
import AVFoundation

class MusicClass {
    
    static let shared = MusicClass()
    
    var audioPlayer = AVAudioPlayer()
    
    private init() {}
    
    func setup(){
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "backMusic3min", ofType: "mp3")!))
            audioPlayer.prepareToPlay()
        } catch {
            print(error)
        }
    }
    func play() {
        audioPlayer.numberOfLoops = -1
        audioPlayer.play()
    }
    
    func stop() {
        audioPlayer.stop()
        audioPlayer.currentTime = 0
        audioPlayer.prepareToPlay()
    }
}
