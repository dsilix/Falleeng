//
//  GameScene.swift
//  Gameplay
//
//  Created by:
//             Alessandro Volpe 🦊
//             Silvio Saturno 🪐
//

import SpriteKit
import GameplayKit
import AVFoundation


struct CategoryMasks{
    static let word: UInt32 = 0x1 << 0
    static let correct: UInt32 = 0x1 << 1
    static let incorrect: UInt32 = 0x1 << 2
}


class GameScene: SKScene,SKPhysicsContactDelegate{
    
    // DIZIONARIO POPOLATO CON PAROLE E EMOJI
    var fruits = ["Apple" : "🍎","Pear" : "🍐","Orange" : "🍊","Lemon" : "🍋" ,  "Banana" : "🍌", "Bear" : "🐻", "UFO" : "👽", "Brain" : "🧠", "Dog" : "🐶", "Cat" : "🐱", "Rabbit" : "🐰", "Fox" : "🦊", "Panda" : "🐼", "Koala" : "🐨", "Lion" : "🦁", "Cow" : "🐮", "Pig" : "🐷", "Frog" : "🐸", "Monkey" : "🐵", "Chiken" : "🐔", "Penguin" : "🐧", "Bird" : "🐦", "Baby Chick" : "🐤", "Duck" : "🦆", "Eagle" : "🦅", "Owl" : "🦉", "Bat" : "🦇", "Wolf" : "🐺", "Boar" : "🐗", "Horse" : "🐴", "Unicorn" : "🦄", "Bee" : "🐝", "Bug" : "🐛", "Butterfly" : "🦋", "Snail" : "🐌", "Ladybird" : "🐞", "Ant" : "🐜", "Mosquito" : "🦟", "Cricket" : "🦗","Spider" : "🕷","Spiderweb" : "🕸", "Scorpion" : "🦂", "Turtle" : "🐢","Snake" : "🐍","Lizard" : "🦎","T-rex" : "🦖", "Dinosaur" : "🦕","Octopus" : "🐙", "Squid" : "🦑", "Shrimp" : "🦐", "Lobster" : "🦞","Crab" : "🦀","Blowfish" : "🐡","Tropical Fish" : "🐠","Fish" :  "🐟","Dolphin" : "🐬","Whale" : "🐳","Shark" : "🦈","Crocodile" : "🐊","Tiger" : "🐅","Leopard" : "🐆","Gorilla" : "🦍","Orangutan" : "🦧","Elephant" : "🐘","Hippopotam" : "🦛", "Rhiniceros" : "🦏","Camel" : "🐪", "Two Hump Camel" : "🐫", "Giraffe" : "🦒","Kangaroo" : "🦘", "Water Buffalo" : "🐃","Ox" : "🐂"]
   
    var levelTimerValue: Int = 60 {
    didSet {
    levelTimerLabel.text = "Time left: \(levelTimerValue)s"
        }
    }
    // SPRITENODES
    var word: SKSpriteNode!
    var choice1: SKSpriteNode!
    var choice2: SKSpriteNode!
    var displScore1: SKSpriteNode!
    var platform: SKSpriteNode!
    var scorecontainer: SKSpriteNode!
    var timecontainer: SKSpriteNode!
    var levelTimerLabel1: SKSpriteNode!
    var istruzione1: SKSpriteNode!
    var pauseBtn = SKSpriteNode()
    var pauseBtn2 = SKSpriteNode()
    var home = SKSpriteNode()
    // LABELNODES
    var wordTxt: SKLabelNode!
    var choice1Txt: SKLabelNode!
    var choice2Txt: SKLabelNode!
    var displScore: SKLabelNode!
    var levelTimerLabel: SKLabelNode!
    var istruzione: SKLabelNode!
    
    
    // POSIZIONI
    var wordOriginalPosition = CGPoint(x: 0, y: 460)
    var scoreOriginalPosition = CGPoint(x: -250, y: 500)
    var timeOriginalPosition = CGPoint(x: 250, y: 515)
    
    // AUDIO
    var correctAudio: AVAudioPlayer!
    var incorrectAudio: AVAudioPlayer!
    var wowAudio: AVAudioPlayer!
    
    // SCORE
   static var score = 0
    
    // NUVOLE
    private var cloud = SKSpriteNode()
    private var cloudMoving: [SKTexture] = []
    private var cloud1 = SKSpriteNode()
    private var cloudMoving1: [SKTexture] = []
    
    //FIAMME
    private var flame = SKSpriteNode()
    private var flameMoving: [SKTexture] = []
    
    
    
    
        
    override func didMove(to view: SKView) {
        // ANIMAZIONE BIRD
        let bird = SKSpriteNode(imageNamed: "tile000")
        let birdAnimation: SKAction
        var textures:[SKTexture] = []
        for i in 0...7{
        textures.append(SKTexture(imageNamed: "tile00\(i)"))
        }
        textures.append(textures[2])
        textures.append(textures[1])
        birdAnimation = SKAction.animate(with: textures, timePerFrame: 0.1)
        bird.position = CGPoint(x:-400, y:400)
        bird.zPosition = 10
        bird.size = CGSize(width: 150, height: 100)
        addChild(bird)
        bird.run(SKAction.repeatForever(birdAnimation))
        let moveBottomLeft = SKAction.move(to: CGPoint(x: 450,y: 400), duration:60.0)
        bird.run(moveBottomLeft)
        
        self.childNode(withName: "pauseBtn") as! SKSpriteNode
        
        self.childNode(withName: "pauseBtn2") as! SKSpriteNode
        
        self.childNode(withName: "home") as! SKSpriteNode
       
        
        word = SKSpriteNode(color: UIColor(red: 0,green: 0,blue: 0,alpha: 0),size: CGSize(width: 217, height: 100))
        word.position = wordOriginalPosition
        addChild(word)
        
        choice1 = SKSpriteNode(color: UIColor(red: 0, green: 0, blue: 0, alpha: 0), size: CGSize(width: 100, height: 100))
        choice1.position = CGPoint(x: -250, y: -517)
        addChild(choice1)
        
        choice2 = SKSpriteNode(color: UIColor(red: 0, green: 0, blue: 0, alpha: 0), size: CGSize(width: 100, height: 100))
        choice2.position = CGPoint(x: 250, y: -517)
        addChild(choice2)
        
        
        // TIMER
        let wait = SKAction.wait(forDuration: 1) //change countdown speed here
        let block = SKAction.run(_:)({
            [unowned self] in

            if self.levelTimerValue > 0{
                self.levelTimerValue -= 1
            }else{
                self.removeAction(forKey: "countdown")
                let backBtn = TimeUp(fileNamed: "TimeUp")!
                       
                       
                       let reveal = SKTransition.fade(withDuration: 0.2)
                backBtn.scaleMode = .aspectFill
                self.view?.presentScene(backBtn, transition: reveal)
            }
        })
        let sequence = SKAction.sequence([wait,block])
        run(SKAction.repeatForever(sequence), withKey: "countdown")
    
        
        // TIMER
        levelTimerLabel1 = SKSpriteNode(color: UIColor(red: 0, green: 0, blue: 0, alpha: 0), size: CGSize(width: 100, height: 100))
        levelTimerLabel1.size = CGSize(width: 300, height: 100)
        levelTimerLabel1.position = timeOriginalPosition
        levelTimerLabel1.zPosition = 300
        addChild(levelTimerLabel1)
        
        levelTimerLabel = SKLabelNode(text: "")
        levelTimerLabel.position = CGPoint.zero
        levelTimerLabel.fontSize = 45
        levelTimerLabel.fontName = "Chewy-Regular"
        levelTimerLabel.fontColor = UIColor.brown
        levelTimerLabel1.addChild(levelTimerLabel)
        
        
        // BOX LEGNO
        platform = SKSpriteNode(imageNamed: "wood")
        platform.size = CGSize(width: 300, height: 100)
        platform.position = CGPoint(x: 0, y: 200)
        addChild(platform)
        
        // BOX SCORE
        scorecontainer = SKSpriteNode(imageNamed: "score")
        scorecontainer.size = CGSize(width: 300, height: 100)
        scorecontainer.position = CGPoint(x: -250, y: 530)
        scorecontainer.zPosition = 10
        addChild(scorecontainer)
        
        // BOX TIMER
        timecontainer = SKSpriteNode(imageNamed: "number")
        timecontainer.size = CGSize(width: 300, height: 100)
        timecontainer.position = CGPoint(x: 250, y: 530)
        timecontainer.zPosition = 10
        addChild(timecontainer)
        
       
        // SCORE (AI POSTERI: NON CI SBATTETE LA TESTA, SE VI SERVE COPIATELO COSI COM'E' -Silvio)
        displScore1 = SKSpriteNode(color: UIColor(red: 0, green: 0, blue: 0, alpha: 0), size: CGSize(width: 100, height: 100))
        displScore1.size = CGSize(width: 300, height: 100)
        displScore1.position = scoreOriginalPosition
        displScore1.zPosition = 11
        addChild(displScore1)
        
        displScore = SKLabelNode(text: "")
        displScore.position = CGPoint.zero
        displScore.fontSize = 80
        
        displScore.fontName = "Chewy-Regular"
        displScore.fontColor = UIColor.brown
        displScore1.addChild(displScore)
        
        //ISTRUZIONE
        istruzione1 = SKSpriteNode(color: UIColor(red: 0, green: 0, blue: 0, alpha: 0), size: CGSize(width: 100, height: 100))
        istruzione1.size = CGSize(width: 300, height: 100)
        istruzione1.position = CGPoint(x: 0, y: 110)
        istruzione1.zPosition = 11
        addChild(istruzione1)
        
        istruzione = SKLabelNode(text: "")
        istruzione.position = CGPoint.zero
        istruzione.fontSize = 40
        
        istruzione.fontName = "Chewy-Regular"
        istruzione.fontColor = UIColor.brown
        istruzione1.addChild(istruzione)
        
        // PAROLA
        wordTxt = SKLabelNode(text: "")
        wordTxt.position = CGPoint.zero
        wordTxt.zPosition = 20
        wordTxt.fontSize = 100
        wordTxt.fontName = "Chewy-Regular"
        wordTxt.fontColor = UIColor.brown
        word.addChild(wordTxt)
        
        // EMOJI
        choice1Txt = SKLabelNode(text: "")
        choice1Txt.position = CGPoint.zero
        choice1Txt.fontSize = 200
        choice1Txt.fontColor = UIColor.black
        choice1.addChild(choice1Txt)
        
        choice2Txt = SKLabelNode(text: "")
        choice2Txt.position = CGPoint.zero
        choice2Txt.fontSize = 200
        choice2Txt.fontColor = UIColor.black
        choice2.addChild(choice2Txt)
        
        // FISICA ELEMENTI GIOCO
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        
        word.physicsBody = SKPhysicsBody(rectangleOf: word.size)
        
        platform.physicsBody = SKPhysicsBody(rectangleOf: platform.size)
        platform.physicsBody?.affectedByGravity = false
        platform.physicsBody?.isDynamic = false
        
        choice1.physicsBody = SKPhysicsBody(rectangleOf: choice1.size)
        choice1.physicsBody?.affectedByGravity = false
        choice1.physicsBody?.isDynamic = false
        
        choice2.physicsBody = SKPhysicsBody(rectangleOf: choice2.size)
        choice2.physicsBody?.affectedByGravity = false
        choice2.physicsBody?.isDynamic = false
    
        physicsWorld.contactDelegate = self
        
        word.physicsBody?.categoryBitMask = CategoryMasks.word
        word.physicsBody?.contactTestBitMask = CategoryMasks.correct | CategoryMasks.incorrect
        
        setLabels()
        updateScoreLabel()
        
        // MUSICA
        let correctPath = Bundle.main.path(forResource: "Correct", ofType: "wav")
        let incorrectPath = Bundle.main.path(forResource: "Wrong", ofType: "wav")
        let wowPath = Bundle.main.path(forResource: "wow", ofType: "mp3")
        
        let correctURL = URL(fileURLWithPath: correctPath!)
        let incorrectURL = URL(fileURLWithPath: incorrectPath!)
        let wowURL = URL(fileURLWithPath: wowPath!)
        
        do {
           try correctAudio = AVAudioPlayer(contentsOf: correctURL)
           try incorrectAudio = AVAudioPlayer(contentsOf: incorrectURL)
           try wowAudio = AVAudioPlayer(contentsOf: wowURL)
            
            correctAudio.prepareToPlay()
            incorrectAudio.prepareToPlay()
            wowAudio.prepareToPlay()
        } catch {
            print(error)
            
        }
        buildCloud()
        animateCloud()
    }
    
    // _____________ SEZIONE FUNCTIONS _____________
    
    // ANIMAZIONE NUVOLE
     func buildCloud() {
          let cloudAnimatedAtlas = SKTextureAtlas(named: "clouds")
          var walkFrames: [SKTexture] = []
     
          let numImages = cloudAnimatedAtlas.textureNames.count
          for i in 1...numImages {
            let cloudTextureName = "cloud\(i)"
            walkFrames.append(cloudAnimatedAtlas.textureNamed(cloudTextureName))
          }
            let cloudAnimatedAtlas1 = SKTextureAtlas(named: "clouds")
            var walkFrames1: [SKTexture] = []
     
            let numImages1 = cloudAnimatedAtlas1.textureNames.count
            for i in 1...numImages1 {
              let cloudTextureName1 = "cloud\(i)"
              walkFrames1.append(cloudAnimatedAtlas1.textureNamed(cloudTextureName1))
            }
     
          cloudMoving = walkFrames
            let firstFrameTexture = cloudMoving[0]
            cloud = SKSpriteNode(texture: firstFrameTexture)
            cloud.position = CGPoint(x: -500, y: 400)
            cloud.zPosition = 5
            cloud.size = CGSize(width: 200, height: 200)
            addChild(cloud)
            cloudMoving1 = walkFrames1
              let firstFrameTexture1 = cloudMoving1[0]
              cloud1 = SKSpriteNode(texture: firstFrameTexture1)
              cloud1.position = CGPoint(x: 500, y: 500)
              cloud1.zPosition = 5
              cloud1.size = CGSize(width: 200, height: 200)
              addChild(cloud1)
        }
    func animateCloud() {
          cloud.run(SKAction.repeatForever(
            SKAction.animate(with: cloudMoving,
                             timePerFrame: 0.3,
                             resize: false,
                             restore: true)),
            withKey:"MovingCloud")
            let move = SKAction.moveTo(x: 500, duration: 8)
            let move2 = SKAction.moveTo(x: -500, duration: 8)
            let action = SKAction.sequence([move,move2])
            cloud.run(SKAction.repeatForever(action))
            cloud1.run(SKAction.repeatForever(
              SKAction.animate(with: cloudMoving1,
                               timePerFrame: 0.3,
                               resize: false,
                               restore: true)),
              withKey:"MovingCloud1")
     
              let action1 = SKAction.sequence([move2,move])
              cloud1.run(SKAction.repeatForever(action1))
        }
    
    func buildFlame() {
        let flameAnimatedAtlas = SKTextureAtlas(named: "Flame")
        var walkFrames: [SKTexture] = []
   
        let numImages = flameAnimatedAtlas.textureNames.count
        for i in 1...numImages {
          let flameTextureName = "flame\(i)"
          walkFrames.append(flameAnimatedAtlas.textureNamed(flameTextureName))
        }
        flameMoving = walkFrames
          let firstFrameTexture = flameMoving[0]
          flame = SKSpriteNode(texture: firstFrameTexture)
          flame.position = CGPoint(x: -240, y: 540)
          flame.zPosition = 500
          flame.size = CGSize(width: 70, height: 100)
          addChild(flame)
       
        let action = SKAction.repeat(SKAction.animate(with: flameMoving, timePerFrame: 0.1, resize: false, restore: false), count: 1)
        let action1 = SKAction.hide()
        let move = SKAction.sequence([action,action1])
        flame.run(move)
        
        
        
        
        
    }
  
    
    
    // MOSTRA LO SCORE
    func updateScoreLabel(){
        if GameScene.score < 0 {
            GameScene.score += 1
        }
        displScore.text = String(GameScene.score)
    }
   
    // SETTA I LABELS
    func setLabels(){
        var nameArray = [String]()
        var iconArray = [String]()
        
        for(key, value) in fruits {
            nameArray.append(key)
            iconArray.append(value)
        }
        
        let correctIndex = Int(arc4random_uniform(70))
        let chosenChoice = Int(arc4random_uniform(2))
        let incorrectIndex = Int(arc4random_uniform(70))
        
        wordTxt.text = nameArray[correctIndex]
        levelTimerLabel.text = "Time left: \(levelTimerValue)s"
        
        istruzione.text = "Drag the word on the right emoji"
        if GameScene.score > 0 {
            self.istruzione.text = ""
        }
        
        if chosenChoice == 0 {
            choice1Txt.text = iconArray[correctIndex]
            choice1.physicsBody?.categoryBitMask = CategoryMasks.correct
            
            iconArray.remove(at: correctIndex)
            
            choice2Txt.text = iconArray[incorrectIndex]
            choice2.physicsBody?.categoryBitMask = CategoryMasks.incorrect
            
        }else {
            choice2Txt.text = iconArray[correctIndex]
            choice2.physicsBody?.categoryBitMask = CategoryMasks.correct
            
            iconArray.remove(at: correctIndex)
            
            choice1Txt.text = iconArray[incorrectIndex]
            choice1.physicsBody?.categoryBitMask = CategoryMasks.incorrect
            updateScoreLabel()
            
        }
    }
    

    func didBegin(_ contact: SKPhysicsContact) {
        var body1Id: UInt32!
        var body2Id: UInt32!
        
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
            body1Id = contact.bodyA.categoryBitMask
            body2Id = contact.bodyB.categoryBitMask
            
        } else {
            body1Id = contact.bodyB.categoryBitMask
            body2Id = contact.bodyA.categoryBitMask
        }
        
        if body1Id == CategoryMasks.word {
            var correct: Bool?
            if body2Id == CategoryMasks.correct {
                print("CORRECT")
                GameScene.score += 1
                correct = true
                correctAudio.play()
                print(GameScene.score)
                setLabels()
            
            } else if body2Id == CategoryMasks.incorrect {
                print("INCORRECT")
                GameScene.score -= 1
                incorrectAudio.play()
                correct = false
                print(GameScene.score)
            }
            
            if let actuallyCorrect = correct  {
            word.physicsBody = nil
            word.zRotation = 0
            word.position = wordOriginalPosition
            word.physicsBody = SKPhysicsBody(rectangleOf: word.size)
            word.physicsBody?.categoryBitMask = CategoryMasks.word
            word.physicsBody?.contactTestBitMask = CategoryMasks.correct | CategoryMasks.incorrect
                updateScoreLabel()
                if actuallyCorrect {
                    
                    if GameScene.score % 5 == 0 {
                        wowAudio.play()
                    }
                   // let correctParticle = NSKeyedUnarchiver.unarchiveObject(withFile: correctPath) as! SKEmitterNode
                    let correctParticle = SKEmitterNode(fileNamed: "CorrectParticle")
                    correctParticle!.position = CGPoint.zero
                   // correctParticle!.particleColor = UIColor.green
                    addChild(correctParticle!)
                    
                }else{
                    buildFlame()
                    
                    
                    
                }
        }
    }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //if action(forKey: "countdown") != nil {removeAction(forKey: "countdown")}
        if let touch = touches.first {
            let touchLoc = touch.location(in: self)
            let touchWhere = nodes(at: touchLoc)
            
            if !touchWhere.isEmpty {
                for node in touchWhere {
                    if let node = node as? SKSpriteNode {
                        if node == word {
                            word.position = touchLoc
                            word.physicsBody?.affectedByGravity = false
                        }
                    }
                }
            }
        }
            for touch in touches {
                     let location = touch.location(in: self)
                     let touchedNode = atPoint(location)
                     
                
                     if touchedNode.name == "pauseBtn" {
                        self.scene?.view?.isPaused = true
                        
                     }
                }
        for touch in touches {
                 let location = touch.location(in: self)
                 let touchedNode = atPoint(location)
                 
            
                 if touchedNode.name == "pauseBtn2" {
                    self.scene?.view?.isPaused = false
                    
                 }
            }
        
     
        
        for touch in touches {
                 
            
                 let location = touch.location(in: self)
                 let touchedNode = atPoint(location)
                 if touchedNode.name == "home" {
                    self.scene?.view?.isPaused = false
                    GameScene.score = 0
                    
                    let hScore = GameMenu(fileNamed: "GameMenu")!
                           
                           
                           let reveal3 = SKTransition.fade(withDuration: 0.2)
                    hScore.scaleMode = .aspectFill
                    self.view?.presentScene(hScore, transition: reveal3)
                 }
        
    }
        updateScoreLabel()
        
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if let touch = touches.first {
            let touchLoc = touch.location(in: self)
            let touchWhere = nodes(at: touchLoc)
            
            if !touchWhere.isEmpty {
                for node in touchWhere {
                    if let node = node as? SKSpriteNode {
                        if node == word {
                            word.position = touchLoc
                        }
                    }
                }
            }
        }
        updateScoreLabel()
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
       
        if let touch = touches.first {
            let touchLoc = touch.location(in: self)
            let touchWhere = nodes(at: touchLoc)
            
            if !touchWhere.isEmpty {
                for node in touchWhere {
                    if let node = node as? SKSpriteNode {
                        if node == word {
                            word.position = touchLoc
                            word.physicsBody?.affectedByGravity = true
                        }
                    }
                }
            }
        }
        updateScoreLabel()
    }

 }

