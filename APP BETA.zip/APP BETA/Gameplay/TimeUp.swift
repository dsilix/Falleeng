//
//  TimeUp.swift
//  Gameplay
//
//  Created by Alessandro Volpe on 29/10/2020.
//

import Foundation
import SpriteKit
import AVFoundation

class TimeUp: SKScene {
    var back = SKSpriteNode()
    var score1: SKSpriteNode!
    var score: SKLabelNode!
    
    private var cloud = SKSpriteNode()
    private var cloudMoving: [SKTexture] = []
    private var cloud1 = SKSpriteNode()
    private var cloudMoving1: [SKTexture] = []
    var TimeAudio: AVAudioPlayer!
    
    override func didMove(to view: SKView) {
        
        self.childNode(withName: "backBtn") as! SKSpriteNode
        self.childNode(withName: "retryBtn") as! SKSpriteNode
        buildCloud()
        animateCloud()
    }
    func buildCloud() {
         let cloudAnimatedAtlas = SKTextureAtlas(named: "clouds")
         var walkFrames: [SKTexture] = []
    
         let numImages = cloudAnimatedAtlas.textureNames.count
         for i in 1...numImages {
           let cloudTextureName = "cloud\(i)"
           walkFrames.append(cloudAnimatedAtlas.textureNamed(cloudTextureName))
         }
           let cloudAnimatedAtlas1 = SKTextureAtlas(named: "clouds")
           var walkFrames1: [SKTexture] = []
    
           let numImages1 = cloudAnimatedAtlas1.textureNames.count
           for i in 1...numImages1 {
             let cloudTextureName1 = "cloud\(i)"
             walkFrames1.append(cloudAnimatedAtlas1.textureNamed(cloudTextureName1))
           }
    
         cloudMoving = walkFrames
           let firstFrameTexture = cloudMoving[0]
           cloud = SKSpriteNode(texture: firstFrameTexture)
           cloud.position = CGPoint(x: -500, y: 400)
           cloud.zPosition = 5
           cloud.size = CGSize(width: 200, height: 200)
           addChild(cloud)
           cloudMoving1 = walkFrames1
             let firstFrameTexture1 = cloudMoving1[0]
             cloud1 = SKSpriteNode(texture: firstFrameTexture1)
             cloud1.position = CGPoint(x: 500, y: 500)
             cloud1.zPosition = 5
             cloud1.size = CGSize(width: 200, height: 200)
             addChild(cloud1)
       }
    func animateCloud() {
        let TimePath = Bundle.main.path(forResource: "fabio", ofType: "mpeg")
        let TimeURL = URL(fileURLWithPath: TimePath!)
        do {
           try TimeAudio = AVAudioPlayer(contentsOf: TimeURL)
            TimeAudio.prepareToPlay()
        } catch {
            print(error)
            
        }
        TimeAudio.play()
        
        score1 = SKSpriteNode(color: UIColor(red: 0, green: 0, blue: 0, alpha: 0), size: CGSize(width: 100, height: 100))
        score1.size = CGSize(width: 300, height: 100)
        score1.position = CGPoint(x: 0, y: 410)
        score1.zPosition = 11
        addChild(score1)
        
        score = SKLabelNode(text: "")
        score.position = CGPoint.zero
        score.fontSize = 100
        
        score.fontName = "Chewy-Regular"
        score.fontColor = UIColor.brown
        score1.addChild(score)
        score.text = "Your Score: \(String(GameScene.score))"
          cloud.run(SKAction.repeatForever(
            SKAction.animate(with: cloudMoving,
                             timePerFrame: 0.3,
                             resize: false,
                             restore: true)),
            withKey:"MovingCloud")
            let move = SKAction.moveTo(x: 500, duration: 8)
            let move2 = SKAction.moveTo(x: -500, duration: 8)
            let action = SKAction.sequence([move,move2])
            cloud.run(SKAction.repeatForever(action))
            cloud1.run(SKAction.repeatForever(
              SKAction.animate(with: cloudMoving1,
                               timePerFrame: 0.3,
                               resize: false,
                               restore: true)),
              withKey:"MovingCloud1")
     
              let action1 = SKAction.sequence([move2,move])
              cloud1.run(SKAction.repeatForever(action1))
        }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
           let location = touch.location(in: self)
           let touchedNode = atPoint(location)
           if touchedNode.name == "backBtn" {
              
              let backBtn = GameMenu(fileNamed: "GameMenu")!
                     
                     
                     let reveal = SKTransition.fade(withDuration: 0.2)
              backBtn.scaleMode = .aspectFill
              self.view?.presentScene(backBtn, transition: reveal)
           }
            if touchedNode.name == "retryBtn" {
               
               let backBtn = GameScene(fileNamed: "GameScene")!
                      
                      
                      let reveal = SKTransition.fade(withDuration: 0.2)
               backBtn.scaleMode = .aspectFill
               self.view?.presentScene(backBtn, transition: reveal)
            }
   }
    }
}

