//
//  MainMenuTests.swift
//  MainMenuTests
//
//  Created by Simone on 27/10/2020.
//

import Foundation
import SpriteKit

class Settings: SKScene {
    var back = SKSpriteNode()
    private var cloud = SKSpriteNode()
    private var cloudMoving: [SKTexture] = []
    private var cloud1 = SKSpriteNode()
    private var cloudMoving1: [SKTexture] = []
    
    override func didMove(to view: SKView) {
        self.childNode(withName: "backSettings") as! SKSpriteNode
        self.childNode(withName: "offButton") as! SKSpriteNode
        self.childNode(withName: "onMusic") as! SKSpriteNode
        buildCloud()
        animateCloud()
    }
    
    
    func buildCloud() {
         let cloudAnimatedAtlas = SKTextureAtlas(named: "clouds")
         var walkFrames: [SKTexture] = []
    
         let numImages = cloudAnimatedAtlas.textureNames.count
         for i in 1...numImages {
           let cloudTextureName = "cloud\(i)"
           walkFrames.append(cloudAnimatedAtlas.textureNamed(cloudTextureName))
         }
           let cloudAnimatedAtlas1 = SKTextureAtlas(named: "clouds")
           var walkFrames1: [SKTexture] = []
    
           let numImages1 = cloudAnimatedAtlas1.textureNames.count
           for i in 1...numImages1 {
             let cloudTextureName1 = "cloud\(i)"
             walkFrames1.append(cloudAnimatedAtlas1.textureNamed(cloudTextureName1))
           }
    
         cloudMoving = walkFrames
           let firstFrameTexture = cloudMoving[0]
           cloud = SKSpriteNode(texture: firstFrameTexture)
           cloud.position = CGPoint(x: -500, y: 500)
           cloud.zPosition = 5
           cloud.size = CGSize(width: 200, height: 200)
           addChild(cloud)
           cloudMoving1 = walkFrames1
             let firstFrameTexture1 = cloudMoving1[0]
             cloud1 = SKSpriteNode(texture: firstFrameTexture1)
             cloud1.position = CGPoint(x: 500, y: 580)
             cloud1.zPosition = 5
             cloud1.size = CGSize(width: 200, height: 200)
             addChild(cloud1)
       }
    func animateCloud() {
          cloud.run(SKAction.repeatForever(
            SKAction.animate(with: cloudMoving,
                             timePerFrame: 0.3,
                             resize: false,
                             restore: true)),
            withKey:"MovingCloud")
            let move = SKAction.moveTo(x: 500, duration: 8)
            let move2 = SKAction.moveTo(x: -500, duration: 8)
            let action = SKAction.sequence([move,move2])
            cloud.run(SKAction.repeatForever(action))
            cloud1.run(SKAction.repeatForever(
              SKAction.animate(with: cloudMoving1,
                               timePerFrame: 0.3,
                               resize: false,
                               restore: true)),
              withKey:"MovingCloud1")
     
              let action1 = SKAction.sequence([move2,move])
              cloud1.run(SKAction.repeatForever(action1))
        }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
                 let location = touch.location(in: self)
                 let touchedNode = atPoint(location)
                 if touchedNode.name == "backSettings" {
                    
                    let backBtn = GameMenu(fileNamed: "GameMenu")!
                           
                           
                    let reveal = SKTransition.fade(withDuration: 0.2)
                    backBtn.scaleMode = .aspectFill
                    self.view?.presentScene(backBtn, transition: reveal)
                 }
            if touchedNode.name == "offButton" {
                MusicClass.shared.stop()
            }
            if touchedNode.name == "onMusic" {
                MusicClass.shared.play()
            }
            
    }
    }
}
